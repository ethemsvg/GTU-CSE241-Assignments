#include "util.hpp"

using namespace std;


int main(){


	Shapes tetromino_type;
	int tetrominos_number;
	int i = 0;
	char tetrotype;

	vector<Tetromino> tetrominos;  // 1D vector which holds the tetrominos.

	cout << "Please enter the amount of tetrominos." << endl;
	cin >> tetrominos_number;

	while( cin.fail() ){ // Checks the input for any bad entries.
		cin.clear();
		cin.ignore();
		cout << "Please enter a valid input." << endl;
		cin >> tetrominos_number;
	}

	
	// Tetrominos are created as the user types in the types, and pushed into the tetrominos vector.

	for(i=0;i<tetrominos_number;i++){

		Tetromino temp;
		tetrominos.push_back(temp);

	}

	// The position of the first tetromino is arranged in a way that there is no blank 
	// units on the bottom left corner of the grid.

	tetrominos[0].fixFirst(tetrominos[0]);

	for(i=1;i<tetrominos_number;i++){

		tetrominos[i].makeFit(tetrominos[i-1],tetrominos[i]);

	}

	// All tetrominos are printed horizontally.

	tetrominos[0].printTetrominosOrdered(tetrominos);

	
	return 0;

}