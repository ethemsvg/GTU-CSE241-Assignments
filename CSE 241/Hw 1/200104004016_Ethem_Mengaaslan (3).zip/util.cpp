#include "util.hpp"

using namespace std;

/*

const vector<Tetromino>& tetrominos: The 1D vector where the tetromino objects are stored.

This function creates a 2D vector of size Number Of Tetrominos * 4 .

Then fills this array with all the tetrominos in horizontal order, then prints the final 
2D vector on the terminal screen.

*/
void Tetromino::printTetrominosOrdered(const vector<Tetromino>& tetrominos){

	auto numOfTetrominos = tetrominos.size();
	int i = 0;
	int j = 0;
	int k = 0;

	for(i=0;i<4;i++){

		for(j=0;j<numOfTetrominos;j++){ // Iterates over every tetromino for every row (i).

			for(k=0;k<4;k++){ // Iterates over every unit on 1D vector of size 4.
				if(tetrominos[j].tetromino_vector[i][k] == 1){
					cout << tetrominos[j].typechar;
				}else if(tetrominos[j].tetromino_vector[i][k] == 0){
					cout << ' ';
				}
			}

		}
		cout << endl;
	}



}

/*

Tetromino& left: The Tetromino on the left.
Tetromino& right: The Tetromino on the right.

This function gets a pair of Tetrominos and makes them fit together by simply
rotating the right one to a form which it will fit the left one.

meaningful_column: Since all the tetrominos are stored in 4x4 vectors, there are columns on the right 
which are completely empty. When comparing the tetrominos, these columns must be ignored. Meaningful
column is the column which is the last column that includes any blocks of a tetromino.

It also gets input from the canFit() function to keep rotating the Tetromino or to stop.

*/

Tetromino Tetromino::makeFit(Tetromino& left, Tetromino& right){

	int counter = 0;

	int meaningful_column = 3;

	if(left.tetromino_vector[0][3] == 0 && left.tetromino_vector[1][3] == 0 && left.tetromino_vector[2][3] == 0 && left.tetromino_vector[3][3] == 0  ){

		meaningful_column = 2;

	}

	if(left.tetromino_vector[0][2] == 0 && left.tetromino_vector[1][2] == 0 && left.tetromino_vector[2][2] == 0 && left.tetromino_vector[3][2] == 0  ){

		meaningful_column = 1;

	}


	while( canFit(left,right,meaningful_column) == false){
		right.rotate_tetromino('R');
		counter++;

		if(canFit(left,right,meaningful_column) == true){
			return right;
		}

		if(counter >= 4){
			return right;

		}

	}

	return right;

}


/*

Tetromino& left: Tetromino on the left.

Tetromino& right: Tetromino on the right.

int meaningful_column: Since all the tetrominos are stored in 4x4 vectors, there are columns on the right 
which are completely empty. When comparing the tetrominos, these columns must be ignored. Meaningful
column is the column which is the last column that includes any blocks of a tetromino.


The comparing mechanism compares the right column of the left tetromino with the left column of the 
right tetromino, resolves the fitting condition of the right tetromino to the left tetromino.

*/

bool Tetromino::canFit(Tetromino& left, Tetromino& right,int meaningful_column){

	// This is the case where two tetrominos are back to back with full units.
	
	if( (left.tetromino_vector[3][meaningful_column] == 1 && right.tetromino_vector[3][0] == 1 &&
		   left.tetromino_vector[2][meaningful_column] == 1 && right.tetromino_vector[2][0] == 1 ) ){

		return true;

	}
	// This is the case where the one tetrominos unit is empty and the corresponding unit on the other side is full.

	else if( (left.tetromino_vector[3][meaningful_column] != right.tetromino_vector[3][0] &&
		   left.tetromino_vector[2][meaningful_column] != right.tetromino_vector[2][0] && left.tetromino_vector[3][2] != 0 && right.tetromino_vector[3][1] != 0) ){

		return true;
	// This case is where the statement decides to fill the lowest row rather than the upper rows (worst case scenario).

	}else if( (left.tetromino_vector[3][meaningful_column] == 0 && right.tetromino_vector[3][0] == 1) && 
				(left.tetromino_vector[2][meaningful_column] == 0 && right.tetromino_vector[2][0] == 0) 
		){

		return true;
	}

	// The other conditions return false which ends up with the Tetromino rotating.

	else return false;


}
/*

const char& RorL: The direction of the rotation (Right or Left).

This function simply Transposes the 2D vector and then mirrors it to the y axis for left rotation .
												and mirrors it to the x axis for right rotation	.	

Also it moves the 2D vector to the most left and bottom side of the matrix.

If there is a empty row on bottom of the Tetromino, (or two, or three rows), the rows are shifted to the bottom of the matrix;
Then if there are empty columns on the left of the Tetromino (or two, or three columns), the columns are shifted to the left side of the matrix.

*/
void Tetromino::rotate_tetromino(const char& RorL){ 

	int hold;
	int i=0;
	int j=0;

	vector<vector<int>> temp;
	vector<vector<int>> rotateNinety;

	if( tetromino_type == Shapes::S || tetromino_type == Shapes::Z || tetromino_type == Shapes::L || tetromino_type == Shapes::J || tetromino_type == Shapes::T || tetromino_type == Shapes::I ){ ///////////////////////////////////////////////////////////////////////////////////////////////////////

	    temp = {
	        {1, 2, 3, 4},
	        {4, 5, 6, 7},
	        {7, 8, 9, 10},
	        {11, 12, 13, 14}
	    };

	    rotateNinety = {
	        {1, 2, 3, 4},
	        {4, 5, 6, 7},
	        {7, 8, 9, 10},
	        {11, 12, 13, 14}
	    };

		for(i=0;i<4;i++){

			for(j=0;j<4;j++){

				temp[i][j] = tetromino_vector[j][i];  // temp is the Transpose of the tetromino_vector.
													  // The rows are rewritten as columns in order to get the Transpose.
			}
		}

		if(RorL == 'R'){

			for(i=0;i<4;i++){

				rotateNinety[i][0] = temp[i][3];  // Mirroring the matrix on the Y axis.
				rotateNinety[i][1] = temp[i][2];
				rotateNinety[i][2] = temp[i][1];
				rotateNinety[i][3] = temp[i][0];
			}
		}
		else if(RorL == 'L'){

			for(i=0;i<4;i++){

				rotateNinety[3][i] = temp[0][i];  // Mirroring the matrix on the X axis.
				rotateNinety[2][i] = temp[1][i];
				rotateNinety[1][i] = temp[2][i];
				rotateNinety[0][i] = temp[3][i];
			}

		}
			// Slides tetrominos to the left as much as possible.

		while((rotateNinety[0][0] == 0 && rotateNinety[1][0] == 0 && rotateNinety[2][0] == 0 && rotateNinety[3][0] == 0)){

		if(  (rotateNinety[0][1] == 0 && rotateNinety[1][1] == 0 && rotateNinety[2][1] == 0 && rotateNinety[3][1] == 0) && 
			 (rotateNinety[0][0] == 0 && rotateNinety[1][0] == 0 && rotateNinety[2][0] == 0 && rotateNinety[3][0] == 0)  ){  // slides the tetromino to the left side of the matrix
																																// if there is an empty column.	
			rotateNinety[0][0] = rotateNinety[0][2];
			rotateNinety[1][0] = rotateNinety[1][2];
			rotateNinety[2][0] = rotateNinety[2][2];
			rotateNinety[3][0] = rotateNinety[3][2];

			rotateNinety[0][1] = rotateNinety[0][3];
			rotateNinety[1][1] = rotateNinety[1][3];
			rotateNinety[2][1] = rotateNinety[2][3];
			rotateNinety[3][1] = rotateNinety[3][3];

			rotateNinety[0][2] = 0;
			rotateNinety[1][2] = 0;
			rotateNinety[2][2] = 0;
			rotateNinety[3][2] = 0;

			rotateNinety[0][3] = 0;
			rotateNinety[1][3] = 0;
			rotateNinety[2][3] = 0;
			rotateNinety[3][3] = 0;

		}
		else if(rotateNinety[0][0] == 0 && rotateNinety[1][0] == 0 && rotateNinety[2][0] == 0 && rotateNinety[3][0] == 0){

			rotateNinety[0][0] = rotateNinety[0][1];
			rotateNinety[1][0] = rotateNinety[1][1];
			rotateNinety[2][0] = rotateNinety[2][1];
			rotateNinety[3][0] = rotateNinety[3][1];

			rotateNinety[0][1] = rotateNinety[0][2];
			rotateNinety[1][1] = rotateNinety[1][2];
			rotateNinety[2][1] = rotateNinety[2][2];
			rotateNinety[3][1] = rotateNinety[3][2];

			rotateNinety[0][2] = rotateNinety[0][3];
			rotateNinety[1][2] = rotateNinety[1][3];
			rotateNinety[2][2] = rotateNinety[2][3];
			rotateNinety[3][2] = rotateNinety[3][3];

			rotateNinety[0][3] = 0; 
			rotateNinety[1][3] = 0;
			rotateNinety[2][3] = 0;
			rotateNinety[3][3] = 0;

		}

	}

		// Slides Tetrominos to the bottom as much as possible.

	while((rotateNinety[3][0] == 0 && rotateNinety[3][1] == 0 && rotateNinety[3][2] == 0 && rotateNinety[3][3] == 0)){

		if(  (rotateNinety[2][0] == 0 && rotateNinety[2][1] == 0 && rotateNinety[2][2] == 0 && rotateNinety[2][3] == 0)  &&
			 (rotateNinety[3][0] == 0 && rotateNinety[3][1] == 0 && rotateNinety[3][2] == 0 && rotateNinety[3][3] == 0)	  ){  

			rotateNinety[3][0] = rotateNinety[1][0];
			rotateNinety[3][1] = rotateNinety[1][1];
			rotateNinety[3][2] = rotateNinety[1][2];
			rotateNinety[3][3] = rotateNinety[1][3];

			rotateNinety[2][0] = rotateNinety[0][0];
			rotateNinety[2][1] = rotateNinety[0][1];
			rotateNinety[2][2] = rotateNinety[0][2];
			rotateNinety[2][3] = rotateNinety[0][3];

			rotateNinety[1][0] = 0;
			rotateNinety[1][1] = 0;
			rotateNinety[1][2] = 0;
			rotateNinety[1][3] = 0;

			rotateNinety[0][0] = 0;
			rotateNinety[0][1] = 0;
			rotateNinety[0][2] = 0;
			rotateNinety[0][3] = 0;

		}
		else if(  (rotateNinety[3][0] == 0 && rotateNinety[3][1] == 0 && rotateNinety[3][2] == 0 && rotateNinety[3][3] == 0)  ){

			rotateNinety[3][0] = rotateNinety[2][0];
			rotateNinety[3][1] = rotateNinety[2][1];
			rotateNinety[3][2] = rotateNinety[2][2];
			rotateNinety[3][3] = rotateNinety[2][3];

			rotateNinety[2][0] = rotateNinety[1][0];
			rotateNinety[2][1] = rotateNinety[1][1];
			rotateNinety[2][2] = rotateNinety[1][2];
			rotateNinety[2][3] = rotateNinety[1][3];

			rotateNinety[1][0] = rotateNinety[0][0];
			rotateNinety[1][1] = rotateNinety[0][1];
			rotateNinety[1][2] = rotateNinety[0][2];
			rotateNinety[1][3] = rotateNinety[0][3];

			rotateNinety[0][0] = 0; 
			rotateNinety[0][1] = 0;
			rotateNinety[0][2] = 0;
			rotateNinety[0][3] = 0;

		}

	}


		// Finally the temporary rotateNinety vector is assigned into the original tetromino vector of the subject vector.

		tetromino_vector = rotateNinety;

	}

	




}

/*

Shapes type: An enum value to determine the type of the Tetromino.

This function basically initalizes the Tetrominos' as a form of a matrix.

*/

void Tetromino::tetromino_vector_filler(Shapes type){ //, vector<vector<int> >& tetromino_vector

	switch(type){

		case Shapes::O:

		tetromino_vector = { {0,0,0,0} , {0,0,0,0} , {1,1,0,0} , {1,1,0,0} };
		break;

		case Shapes::I:

		tetromino_vector = { {0,0,0,0} , {0,0,0,0} , {0,0,0,0} , {1,1,1,1} };
		break;

		case Shapes::T:

		tetromino_vector = { {0,0,0,0} , {0,0,0,0} , {1,1,1,0} , {0,1,0,0} };
		break;

		case Shapes::J:

		tetromino_vector = { {0,0,0,0} , {0,1,0,0} , {0,1,0,0} , {1,1,0,0} };
		break;

		case Shapes::L:

		tetromino_vector = { {0,0,0,0} , {1,0,0,0} , {1,0,0,0} , {1,1,0,0} };
		break;

		case Shapes::S:

		tetromino_vector = { {0,0,0,0} , {0,0,0,0} , {0,1,1,0} , {1,1,0,0} };
		break;

		case Shapes::Z:

		tetromino_vector = { {0,0,0,0} , {0,0,0,0} , {1,1,0,0} , {0,1,1,0} };
		break;

	}

}

/*

The Constructor of the Tetromino Class.

Basically assigns a char value to the typechar for further usages in class functions/methods.

*/

Tetromino::Tetromino(){

	cout << "Enter tetromino type:" << endl;
	cin >> typechar;
	if(typechar == 'O'){
		tetromino_type = Shapes::O;
	}else if(typechar == 'I'){
		tetromino_type = Shapes::I;
	}else if(typechar == 'T'){
		tetromino_type = Shapes::T;
	}else if(typechar == 'J'){
		tetromino_type = Shapes::J;
	}else if(typechar == 'L'){
		tetromino_type = Shapes::L;
	}else if(typechar == 'S'){
		tetromino_type = Shapes::S;
	}else if(typechar == 'Z'){
		tetromino_type = Shapes::Z;
	}else{
		cout << "Incorrect input. Terminating..." << endl;
		exit(1);
	}
	cout << endl;


	tetromino_vector_filler(tetromino_type);

}

/*

Prints the tetrominos as the following method:

Prints the typechar(the type of the tetromino) according to the 1s and 0s
in the matrix. (Print Letter for 1, Space for 0).

*/

void Tetromino::print_tetromino() const {

	int i=0;
	int j=0;
	int counter = 0;

	char display_char;

	display_char = typechar;

	int rows = tetromino_vector.size();
	int columns = tetromino_vector[0].size();


	for(vector<int> i: tetromino_vector){

		for(auto j: i){
			if(j==1){
				cout << display_char;
			}
			else{
				cout << ".";
			}

		}


		cout << endl;
		

	}



	cout << endl;
		
}

/*

Tetromino& veryFirstEntry: The first tetromino type which is entered by the user.

Since the first tetromino does not have a tetromino before it to arrange it's position,
for tetrominos like T and Z there is a blank formed on the bottom left of the plain.

So this function rotates the Tetrominos to the left as there is no blank unit on the bottom left
on the screen.

*/

void Tetromino::fixFirst(Tetromino& veryFirstEntry){

	if( veryFirstEntry.typechar == 'I'){
		veryFirstEntry.rotate_tetromino('L');
	}else if( veryFirstEntry.typechar == 'T'  ){
		veryFirstEntry.rotate_tetromino('L');
		veryFirstEntry.rotate_tetromino('L');
	}else if( veryFirstEntry.typechar == 'Z' ){
		veryFirstEntry.rotate_tetromino('L');
	}


}