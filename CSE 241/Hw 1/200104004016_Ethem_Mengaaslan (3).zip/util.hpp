#include <iostream>
#include <vector>

using namespace std;

// The strongly-typed enum for Tetromino types.

enum class Shapes{O,I,T,J,L,S,Z};

// Tetromino class.

class Tetromino
{

public:
	Tetromino(); // Constructor (This constructor uses strongly-typed enums inside of it to determine the type of the Tetromino)

	Shapes tetromino_type; // Enum variable for tetromino type.
	void print_tetromino() const ; // Function which prints tetrominos singularly.
	void rotate_tetromino(const char& direction); // Function which rotates the tetrominos 90 degrees to the left or right.
	bool canFit(Tetromino& first, Tetromino& second, int meaningful_column); // Function which checks whether the entered tetromino fits to the leftside tetromino.
	Tetromino makeFit(Tetromino& first, Tetromino& second); // Function which rotates a tetromino in a way that it fits to the left tetromino.
	void fixFirst(Tetromino& veryFirstEntry); // Function that fixes the position of the first tetromino entered in a way that there is no blank units between the tetromino and de left border of the grid.
	void printTetrominosOrdered(const vector<Tetromino>& tetrominos); // Function that prints all the tetrominos in order in the best fit possible.

private:
	char typechar; // Type of the tetromino as a char.
	vector<vector<int> > tetromino_vector;	// The 2D Vector which holds the tetrominos as matrixes.
	void tetromino_vector_filler(Shapes type); // The function which fills the 4x4 empty matrixes as the shape of the Tetromino.

};
