#include "driver1.hpp"
#include "driver2.hpp"

using namespace std;

int main(){

	int i = 0;
	int width;
	int length;
	int tetroNumber;  // Number of tetrominos which'll be entered.


	cout << "Please enter the width of the board: ";
	cin >> width;

	cout << "Please enter the length of the board: ";
	cin >> length;

	Tetris playground(width,length);
	playground.createBoard(width,length);
	
	playground.Draw(width,length);
	cout << "Please enter the number of tetrominos" << endl;
	cin >> tetroNumber;

	// Checks for bad inputs, asks again if any.

	while( cin.fail() ){
		cin.clear();
		cin.ignore();
		cout << "Please enter a valid input." << endl;
		cin >> tetroNumber;
	}

	// Runs the program for the requested number of tetrominos.

	for(i=0;i<tetroNumber;i++){
		Tetromino toGo;
		if(i==0){
			toGo.fixFirst(toGo);
		}
		playground.Animate(toGo);
	}
	
	return 0;

}
