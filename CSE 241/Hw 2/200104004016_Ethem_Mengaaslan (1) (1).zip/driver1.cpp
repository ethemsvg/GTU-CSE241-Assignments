#include "driver1.hpp"
#include "driver2.hpp"

using namespace std;

int main(){

	Shapes tetromino_type;
	int tetrominos_number;
	int i = 0;
	char tetrotype;
	int width;
	int length;
	int tetroNumber;
	char charType;

	vector<Tetromino> tetrominos;

	width = 12;
	length = 12;
	tetroNumber = 8;


	Tetromino toGo;
	//cout << "please enter a tetromino type for display." << endl ;
	//cin >> charType;
	//toGo.tetromino_vector_filler(Shapes::O); 

	Tetris playground(width,length);
	
	playground.createBoard(12, 12);
	playground.resizeBoard(12, 12);
	cout << toGo.meaningful_row_func(toGo) << endl;
	cout << toGo.meaningful_column_func(toGo) << endl;
	//playground.addTetromino(toGo);
	//playground.Draw(width,length);
	//playground.Animate(toGo);
	toGo.rotate_tetromino('R'); 
	toGo.fixFirst(toGo); 
	playground.Meaningful2Dgenerator(toGo); 
	playground.DecideRotationCoordinate(toGo); 
	//playground.Fit(toGo, 0); 
	//playground.SlideTetrominoLR(toGo, 'L');
	//playground.LowerTetromino(toGo);
	//playground.removeTetromino(toGo);
	playground.Draw(12, 12);
	playground.addTetromino(toGo);

	return 0;

}