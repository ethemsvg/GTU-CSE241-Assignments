#include <iostream>
#include <vector>
#include <unistd.h>
#include "driver1.hpp"

#ifndef _DRIVER2_HPP_
#define _DRIVER2_HPP_


using namespace std;



// Coordinate class for deciding where to place the tetromino.

class Coordinate{

public:
	void setRow(int r){
		row = r;
	}
	void setColumn(int c){
		column = c;
	}
	int getRow(){
		return row;
	}
	int getColumn(){
		return column;
	}
	void setisBestFit(bool ans){
		isBestFit = ans;
	}
	bool getisBestFit(){
		return isBestFit;
	}
private:
	int row;
	int column;
	bool isBestFit;
};



class Tetris{


	public:
		
		Tetris(const int& w, const int& l); // Constructor which initializes the tetris board.
		void setWidth(int w){
			width = w;
		}
		void setLength(int l){
			length = l;
		}
		vector<vector<int>> Meaningful2Dgenerator(Tetromino piece); // Creates a Meaningful 2D vector out of 4x4 vectors.
		void Animate(Tetromino& piece); // Animates the moves.
		Coordinate DecideRotationCoordinate(Tetromino& piece); // Rotates the tetromino until it fits somewhere.
		Coordinate Fit(Tetromino piece, int shiftRow); // Decides where to place the tetromino.
		void SlideTetrominoLR(Tetromino piece, char direction); // Moves the tetromino horizontally by one unit to the left or right.
		void LowerTetromino(Tetromino piece); // Lowers the tetromino step by step to the bottom.
		void removeTetromino(Tetromino piece); // Removes recently added tetromino from the board.
		void resizeBoard(const int& width, const int& length); // Resizes the board.
		void createBoard(const int& width, const int& length); // Creates the board.
		void Draw(const int& width, const int& length); // Draws the board.
		void addTetromino(Tetromino piece); // Adds tetromino to the board on top middle. 
	private:
		vector<vector<char>> board;
		int width;
		int length;
		int isBotFull = 0;
		int tetrominoCounter = 0;
};

#endif