#include "util.hpp"

//using namespace std;

namespace DayClasses{
/*

list<DayOfYearSet::DayOfYear> arr: List data structure for storing DayOfYear objects.

This is the constructor of the DayOfYearSet class, which is initialized with a list of
DayOfYear objects.

*/

DayOfYearSet::DayOfYearSet(list<DayOfYearSet::DayOfYear> arr){

	days_size = arr.size();

	days_ptr = new DayOfYear[days_size];


	auto i=0;

	for(list<DayOfYearSet::DayOfYear>::iterator itr = arr.begin(); itr != arr.end(); itr++){

		days_ptr[i] = *itr;
		i++;

	}

	for(i=0;i<days_size;i++){


		if(days_ptr[i].getMonthNumber() == 1 || days_ptr[i].getMonthNumber() == 3 || days_ptr[i].getMonthNumber() == 5 || days_ptr[i].getMonthNumber() == 7 || days_ptr[i].getMonthNumber() == 8 || days_ptr[i].getMonthNumber() == 10 || days_ptr[i].getMonthNumber() == 12 ){
			if(days_ptr[i].getDay() < 1 || days_ptr[i].getDay() > 31){
				cout << "Invalid day value. Program terminating.." << endl;
				exit(1);
			}
		}else if(days_ptr[i].getMonthNumber() == 4 || days_ptr[i].getMonthNumber() == 6 || days_ptr[i].getMonthNumber() == 9 || days_ptr[i].getMonthNumber() == 11 ){
			if(days_ptr[i].getDay() < 1 || days_ptr[i].getDay() > 30){
				cout << "Invalid day value. Program terminating.." << endl;
				exit(1);
			}
		}else if(days_ptr[i].getMonthNumber() == 2){
			if(days_ptr[i].getDay() < 1 || days_ptr[i].getDay() > 29){
				cout << "Invalid day value. Program terminating.." << endl;
				exit(1);
			}
		}else if(days_ptr[i].getMonthNumber() < 1 || days_ptr[i].getMonthNumber() > 12){
			cout << "Invalid month value. Program terminating..." << endl;
			exit(1);
		}


	}
	

}

/*

ostream& os: The output stream.

const DayOfYearSet::DayOfYear& day: The object which'll be printed.

Overladoign of the << operator for the DayOfYear object.

*/

ostream& operator << ( ostream& os, const DayOfYearSet::DayOfYear& day ){

	// Exception for unvalid month number entries.

	if (day.getMonthNumber() < 1 || day.getMonthNumber() > 12) {
		throw out_of_range("Invalid month number");
	}

	// Decides the month name accordingly to the number.
	switch (day.getMonthNumber()) {
	case 1:
		os << "January ";
		break;
	case 2:
		os << "February ";
		break;
	case 3:
		os << "March ";
		break;
	case 4:
		os << "April ";
		break;
	case 5:
		os << "May ";
		break;
	case 6:
		os << "June ";
		break;
	case 7:
		os << "July ";
		break;
	case 8:
		os << "August ";
		break;
	case 9:
		os << "September ";
		break;
	case 10:
		os << "October ";
		break;
	case 11:
		os << "November ";
		break;
	case 12:
		os << "December ";
		break;
	default:
		os << "Error in DayOfYear::output. Contact software vendor.";
		break;
	}

	// The Day number is added to the output stream
	os << day.getDay();
	os << endl;

	// Output is returned.
	return os;

}

/*
ostream& os: The output stream.

DayOfYearSet set: The object which'll be printed.

Overloading of the << operator for the DayOfYearSet object.

Prints all the set elements inbetween the curly brackets.

*/
ostream& operator << ( ostream& os,  DayOfYearSet set ){

	int i=0;
	os << "{ ";
	for(i=0;i<set.getDays_size();i++){

		// Reads all the month values and prints the related month name
		switch (set.getDays_ptr()[i].getMonthNumber()) {
		case 1:
			os << "January ";
			break;
		case 2:
			os << "February ";
			break;
		case 3:
			os << "March ";
			break;
		case 4:
			os << "April ";
			break;
		case 5:
			os << "May ";
			break;
		case 6:
			os << "June ";
			break;
		case 7:
			os << "July ";
			break;
		case 8:
			os << "August ";
			break;
		case 9:
			os << "September ";
			break;
		case 10:
			os << "October ";
			break;
		case 11:
			os << "November ";
			break;
		case 12:
			os << "December ";
			break;
		default:
			os << "Error in DayOfYear::output. Contact software vendor.";
		}

		// Adds the day number and a comma, if it's not the last element.
		os << set.getDays_ptr()[i].getDay();
		if(i!=set.getDays_size()-1){
			os << ", ";
		}
		

	}
	// Adds the closing bracket and returns the output.
	os << " }";
	return os;

}

/*

Since the size information is already kept in the class, only thing this function does is
to return the value.

*/

int DayOfYearSet::size(){
	return days_size;
}


/*

DayOfYearSet set: The set which is going to be subtracted from the main set.

This function subtracts 2 sets from each other.

*/

DayOfYearSet DayOfYearSet::operator - (DayOfYearSet set){


	auto i=0;
	auto j=0;
	bool checkContain = false;

	list<DayOfYearSet::DayOfYear> days;

	// Checks if the elements of the object which is being subtracted are present in the main object,
	// if not present, they are pushed into a new set, if present, they are not pushed since they are 
	// considered subtracted
	
	for(i=0;i<this->getDays_size();i++){

		checkContain = false;

		for(j=0;j<set.getDays_size();j++){

			if(getDays_ptr()[i] == set.getDays_ptr()[j]){
				checkContain = true;
			}

		}
		//
		if(!checkContain){
			days.push_back(getDays_ptr()[i]);
		}
		
	}

	// Final set is initialized and returned

	DayOfYearSet newSet(days);
	
	return newSet;

}

/*

DayOfYear day: The object which'll be subtracted from the main set.

For the subtraction of one single DayOfYear object from a Set.

*/
DayOfYearSet DayOfYearSet::operator - (DayOfYear day){

	

	bool containCheck = false;
	auto i=0;
	auto j=0;

	// If the subtracted object is not present in the main set, itself is returned without any modifications.
	// If this block was not present, the size parameter of the object could've gotten messed up.

	for(i=0;i<getDays_size();i++){
		if(getDays_ptr()[i] == day){
			containCheck = true;
		}
	}

	if(containCheck == false){
		return *this;
	}

	

	list<DayOfYearSet::DayOfYear> days;
	

	// Size is declared one less of the original size.

	DayOfYear* newptr = new DayOfYearSet::DayOfYear[getDays_size()-1];

	// All the elements of the main set is pushed into a new object, except the
	// element which is being subtracted.

	for(i=0;i<getDays_size();i++){
		if(getDays_ptr()[i] != day){

			days.push_back(getDays_ptr()[i]); 
		}

	}

	// The final set is initialized and returned

	DayOfYearSet newSet(days);
	

	return newSet;

}

/*

DayOfYear day: The object which's going to be added to the set.

One single DayOfYear object is added into the main Set.

*/

DayOfYearSet DayOfYearSet::operator + (DayOfYear day){

	DayOfYear* new_days_ptr = new DayOfYear[days_size + 1];
	auto i=0;
	auto hasDuplicate = false;

	// Checks if the day which'll be added is already in the set, if not, continues the operation
	// If it is a duplicate, the object itself is returned with no further modfications.

	for(i=0;i<days_size;i++){
		if( (days_ptr[i] == day)){
			hasDuplicate = true;
			break;
		}
	}



	if(!hasDuplicate){

		for(i=0;i<days_size;i++){
			new_days_ptr[i] = days_ptr[i];
		}

		// The pointer is deleted and the new initialization is made with the modified size.

		new_days_ptr[days_size] = day;
		days_size++;
		delete[] days_ptr;
		days_ptr = new_days_ptr;

	}else{
		delete[] new_days_ptr;
	}

	// dereferenced pointer of the object is returned

	return *this;

} 

/*

int index: Index of the element wanted.

This is the overload of square bracket, to reach the elements of the set as a random access feature, using square brackets.

*/

DayOfYearSet::DayOfYear DayOfYearSet::operator [] (int index){

	DayOfYearSet::DayOfYear obj;
	obj = getDays_ptr()[index];
	return obj;

}

/*

DayOfYearSet set: The set which'll be added.

For the addition of 2 sets.

Checks for duplicates, adds the non-duplicate elements from the second set into the first set.

*/
DayOfYearSet DayOfYearSet::operator + (DayOfYearSet set){

 DayOfYear* new_days_ptr = new DayOfYear[getDays_size() + set.getDays_size()];

    auto i=0;
    auto j=0;
    auto actualSize = getDays_size();

    // Copy the elements from the first set into the new set
    for (i = 0; i < getDays_size(); i++) {
        new_days_ptr[i] = days_ptr[i];
    }

    // Loop over the elements in the second set
    for (i = 0; i < set.getDays_size(); i++) {
        bool isDuplicate = false;

        // Loop over the elements and check if the current
        // element from the second set is already in the new array
        for (j = 0; j < getDays_size(); j++) {
            if ( new_days_ptr[j] == set.getDays_ptr()[i] ) {
                // The duplicate element is not added.
                isDuplicate = true;
                break;
            }
        }

        // If the current element is not a duplicate, add it to the new set
        if (!isDuplicate) {
            new_days_ptr[actualSize] = set.getDays_ptr()[i];
            actualSize++;
        }
    }

    // Modify the size of the new set to the actual number of elements
    days_size = actualSize ; 
	
    // Delete the old pointer and replace it with the newly allocated one
    delete[] days_ptr;
    days_ptr = new_days_ptr;

    return *this;

	
} 

/*

Returns the complement of a given set.

*/

DayOfYearSet DayOfYearSet::operator ! (){

	auto i=0;
	auto j=0;

	list<DayOfYearSet::DayOfYear> complementSet;

	// All 365 days of a year as DayOfYear objects are initialized and pushed into a list called complementSet.

	for(i=1;i<32;i++){
		DayOfYearSet::DayOfYear dumday(1,i);
		complementSet.push_back(dumday);
	}
	for(i=1;i<30;i++){
		DayOfYearSet::DayOfYear dumday(2,i);
		complementSet.push_back(dumday);
	}
	for(i=1;i<32;i++){
		DayOfYearSet::DayOfYear dumday(3,i);
		complementSet.push_back(dumday);
	}
	for(i=1;i<31;i++){
		DayOfYearSet::DayOfYear dumday(4,i);
		complementSet.push_back(dumday);
	}
	for(i=1;i<32;i++){
		DayOfYearSet::DayOfYear dumday(5,i);
		complementSet.push_back(dumday);
	}
	for(i=1;i<31;i++){
		DayOfYearSet::DayOfYear dumday(6,i);
		complementSet.push_back(dumday);
	}
	for(i=1;i<32;i++){
		DayOfYearSet::DayOfYear dumday(7,i);
		complementSet.push_back(dumday);
	}
	for(i=1;i<32;i++){
		DayOfYearSet::DayOfYear dumday(8,i);
		complementSet.push_back(dumday);
	}
	for(i=1;i<31;i++){
		DayOfYearSet::DayOfYear dumday(9,i);
		complementSet.push_back(dumday);
	}
	for(i=1;i<32;i++){
		DayOfYearSet::DayOfYear dumday(10,i);
		complementSet.push_back(dumday);
	}
	for(i=1;i<31;i++){
		DayOfYearSet::DayOfYear dumday(11,i);
		complementSet.push_back(dumday);
	}
	for(i=1;i<32;i++){
		DayOfYearSet::DayOfYear dumday(12,i);
		complementSet.push_back(dumday);
	}

	DayOfYearSet complementObj(complementSet);

	// Then the elements of the set whose complement is being created, are subtracted from this 365 element list.

	complementObj = complementObj - *this;

	// Finally, the final set is returned.

	return complementObj;




}

/*

DayOfYearSet set: The set which's being compared.

Compares two sets, if they both contain the same elements regardless of their order, return true, else false.

*/

bool DayOfYearSet::operator == (DayOfYearSet set){

	auto i=0;
	auto j=0;

	bool control = false;

	// If sizes are not equal, returns false.

	if(getDays_size() != set.getDays_size()){
		return false;
	}

	// If an element from the first set is not present in the second, returns false.

	for(i=0;i<getDays_size();i++){
		for(j=0;j<set.getDays_size();j++){
			if(  getDays_ptr()[i] == set.getDays_ptr()[j]  ){
				control = true;
				break;
			}
		}

		if(control == false){
			return false;
		}
	}

	// If the comparisons are compelted and false is not returned, only possibility is that the sets are equal.
	// so true is returned.

    return true;
    
}


/*

DayOfYearSet set: The set which'll be compared.

Compares the sets.


*/
bool DayOfYearSet::operator != (DayOfYearSet set){

//If the sets are not equal, returns true.
//else, returns false.

	if( *this == set ){
		return false;
	}else{
		return true;
	}

}

/*

DayOfYear day: The element which'll be removed.

Removes a specific element from the set.

*/

DayOfYearSet DayOfYearSet::remove(DayOfYear day){

	auto containCheck = false;
	auto i=0;
	int j=0;


	// If the removed object is not present in the main set, itself is returned without any modifications.
	// If this block was not present, the size parameter of the object could've gotten messed up.

	for(i=0;i<getDays_size();i++){
		if(getDays_ptr()[i] == day){
			containCheck = true;
		}
	}

	if(containCheck == false){
		return *this;
	}

	

	list<DayOfYearSet::DayOfYear> days;

	// Size is declared one less of the original size.


	DayOfYear* newptr = new DayOfYearSet::DayOfYear[getDays_size()-1];

	// All the elements of the main set is pushed into a new object, except the
	// element which is being removed.

	for(i=0;i<getDays_size();i++){
		if(getDays_ptr()[i] != day){

			days.push_back(getDays_ptr()[i]); 
		}

	}
	// The final set is initialized and returned

	DayOfYearSet newSet(days);

	return newSet;

}
/*

DayOfYear &day: The pointer to the day which'll be removed.

Same as the remove function above, but gets input as reference rather than value.

*/
DayOfYearSet DayOfYearSet::removerf(DayOfYear &day){

	bool containCheck = false;
	int i=0;
	int j=0;
	// If the subtracted object is not present in the main set, itself is returned without any modifications.
	// If this block was not present, the size parameter of the object could've gotten messed up.

	for(i=0;i<getDays_size();i++){
		if(getDays_ptr()[i] == day){
			containCheck = true;
		}
	}

	if(containCheck == false){
		return *this;
	}

	

	list<DayOfYearSet::DayOfYear> days;
	// Size is declared one less of the original size.

	DayOfYear* newptr = new DayOfYearSet::DayOfYear[getDays_size()-1];
	// All the elements of the main set is pushed into a new object, except the
	// element which is being subtracted.
	for(i=0;i<getDays_size();i++){
		if(getDays_ptr()[i] != day){

			days.push_back(getDays_ptr()[i]); 
		}

	}
	// The final set is initialized and returned

	DayOfYearSet newSet(days);

	return newSet;

}




/*

DayOfYearSet set: The second set needed for the intersection operation.

Returns the intersection of two sets.

Intersection basically means a new set which only has the mutual elements
between the two sets.

*/

DayOfYearSet DayOfYearSet:: operator ^ (DayOfYearSet set){

	list<DayOfYearSet::DayOfYear> intersectionArr;

	int i=0;
	int j=0;

	for(i=0;i<getDays_size();i++){

		for(j=0;j<set.getDays_size();j++){

			if( this->getDays_ptr()[i] == set.getDays_ptr()[j] ){

				intersectionArr.push_back(getDays_ptr()[i]);
			
			}

		}

	}

	DayOfYearSet newObj(intersectionArr);

	return newObj;



} 






// DAY OF YEAR CLASS IMPLENTATIONS:

//Uses iostream and cstdlib:
void DayOfYearSet::DayOfYear::set(int newMonth, int newDay) {
	if ((newMonth >= 1) && (newMonth <= 12))
		month = newMonth;
	else {
		cout << "Illegal month value! Program aborted.\n";
		exit(1);
	}
	if ((newDay >= 1) && (newDay <= 31))
		day = newDay;
	else {
		cout << "Illegal day value! Program aborted.\n";
		exit(1);
	}
}

//Uses iostream and cstdlib:
void DayOfYearSet::DayOfYear::set(int newMonth) {
	if ((newMonth >= 1) && (newMonth <= 12))
		month = newMonth;
	else {
		cout << "Illegal month value! Program aborted.\n";
		exit(1);
	}
	day = 1;
}

int DayOfYearSet::DayOfYear::getMonthNumber() const{
	return month;
}

int DayOfYearSet::DayOfYear::getDay() const{
	return day;
}

//Uses iostream and cstdlib:
void DayOfYearSet::DayOfYear::input() {
	cout << "Enter the month as a number: ";
	cin >> month;
	if ( !(month >= 1) && (month <= 12)){
		cout << "Illegal month value! Program aborted.\n";
		exit(1);
	}
	cout << "Enter the day of the month: ";
	cin >> day;
	
	if( month == 2){
		if( !(day >= 1 && day <= 29) ){
		cout << "Illegal date! Program aborted.\n";
		exit(1);
		}
	}
	else if ( month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12 ) {
		if( !(day >= 1 && day <= 31) ){
		cout << "Illegal date! Program aborted.\n";
		exit(1);
		}
	}
	else if( month == 2 || month == 4 || month == 6 || month == 9 || month == 11 ){
		if( !(day >= 1 && day <= 30) ){
		cout << "Illegal date! Program aborted.\n";
		exit(1);
		}
	}
}

void DayOfYearSet::DayOfYear::output() {
	switch (month) {
	case 1:
		cout << "January ";
		break;
	case 2:
		cout << "February ";
		break;
	case 3:
		cout << "March ";
		break;
	case 4:
		cout << "April ";
		break;
	case 5:
		cout << "May ";
		break;
	case 6:
		cout << "June ";
		break;
	case 7:
		cout << "July ";
		break;
	case 8:
		cout << "August ";
		break;
	case 9:
		cout << "September ";
		break;
	case 10:
		cout << "October ";
		break;
	case 11:
		cout << "November ";
		break;
	case 12:
		cout << "December ";
		break;
	default:
		cout << "Error in DayOfYear::output. Contact software vendor.";
	}

	cout << day;
}

bool DayOfYearSet::DayOfYear::operator <(const DayOfYear b) const {
	if ((month > b.month) || ((month == b.month) && (day > b.day))) {
		return false;
	} else {
		return true;
	}
}

// constructors
DayOfYearSet::DayOfYear::DayOfYear() :
		month(1), day(1) {
}

DayOfYearSet::DayOfYear::DayOfYear(int newMonth, int newDay) :
		month(newMonth), day(newDay) {
}


}