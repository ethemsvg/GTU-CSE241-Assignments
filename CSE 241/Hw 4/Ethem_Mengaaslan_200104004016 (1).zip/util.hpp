#include <iostream>
#include <list>
#include <fstream>

#ifndef _UTIL_HPP_
#define _UTIL_HPP_

using namespace std;

namespace DayClasses{

class DayOfYearSet{

    friend ostream& operator << ( ostream& os,  DayOfYearSet set );

    public:

        class DayOfYear {
    		
			friend ostream& operator << ( ostream& os,  const DayOfYear& day );

            public:
                //Constructors
                DayOfYear();
                DayOfYear(int newMonth, int newDay);
                void input();
                void output();
                void set(int newMonth, int newDay);
                //Precondition: newMonth and newDay form a possible date.
                // overloading of == 
				bool operator == (DayOfYear d){
					if(month == d.month && day == d.day){
						return true;
					}else{
						return false;
					}
				}
                // overloading of != 
				bool operator != (DayOfYear d){
					if(month == d.month && day == d.day){
						return false;
					}else{
						return true;
					}
				}
                void set(int newMonth);
                //Precondition: 1 <= newMonth <= 12
                //Postcondition: The date is set to the first day of the given month.

                int getMonthNumber() const; //Returns 1 for January, 2 for February, etc.
                int getDay() const;

                bool operator <(const DayOfYear b) const;

            private:
                decltype(12) month;
                decltype(31) day;

        };

        DayOfYearSet();
		DayOfYearSet(list<DayOfYearSet::DayOfYear> arr); // consturoctr 
        bool operator == (DayOfYearSet set); // overloading of ==
        bool operator != (DayOfYearSet set);// overloading of != 
        DayOfYearSet removerf(DayOfYear& day); // removes an element by reference
		DayOfYearSet remove(DayOfYear day); // removes an element by value
        DayOfYearSet operator + (DayOfYearSet set); // Combines two sets together. (No duplicates allowed).
        DayOfYearSet operator + (DayOfYear day); // Adds a day into the set.
        DayOfYearSet operator - (DayOfYearSet set); // Returns the difference set.
        DayOfYearSet operator - (DayOfYear day); // Removes an element from the set.
        DayOfYearSet operator ^ (DayOfYearSet set); // Intersection of 2 sets.
        DayOfYearSet operator ! (); // overloading of !, returns complement set
        DayOfYear operator [] (int index); // overloading of [], provides random access.
		int size();
        //getters
		DayOfYear* getDays_ptr(){
			return days_ptr;
		}
		int getDays_size(){
			return days_size;
		}

    private:

        DayOfYear* days_ptr; // The pointer where the DayOfYear objects (elements of the set) will be held.
		int days_size; // Size of the set.

};




}

#endif