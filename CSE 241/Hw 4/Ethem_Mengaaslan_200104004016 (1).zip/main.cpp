
#include "util.hpp"

using namespace std;
using namespace DayClasses;

int main(){

int i,j;
ofstream outputFile;
outputFile.open("output.txt");


// 6 DayOfYear objects are initialized.

DayOfYearSet::DayOfYear d1(1,2);
DayOfYearSet::DayOfYear d2(3,3);
DayOfYearSet::DayOfYear d3(5,7);
DayOfYearSet::DayOfYear d5(3,8);
DayOfYearSet::DayOfYear d4(9,10);
DayOfYearSet::DayOfYear d6(11,11);


// A List of type DayOfYear is initialized.

list <DayOfYearSet::DayOfYear> daySet;


// The DayOfYear objects are pushed in the List.

daySet.push_back(d1);
daySet.push_back(d2);
daySet.push_back(d3);
daySet.push_back(d4);
daySet.push_back(d5);
daySet.push_back(d6);

// The firt set object is initialized with the List above as a parameter of the constructor.
cout << "The firt set object is initialized with a List as a parameter of the constructor." << endl;
outputFile << "The firt set object is initialized a the List as a parameter of the constructor." << endl;

DayOfYearSet mainSetObj(daySet);
cout << "Constructor works. Here is the set: " << mainSetObj << endl << endl;
outputFile << "Constructor works. Here is the set: " << mainSetObj << endl << endl;

// Creating 4 more DayOfYear objects for the second set.

DayOfYearSet::DayOfYear d7(3,3);
DayOfYearSet::DayOfYear d8(9,10);
DayOfYearSet::DayOfYear d9(5,5);
DayOfYearSet::DayOfYear d10(2,1);

// Objects are pushed into anotehr List.

list <DayOfYearSet::DayOfYear> dayListToAdd;

dayListToAdd.push_back(d7);
dayListToAdd.push_back(d8);
dayListToAdd.push_back(d9);
dayListToAdd.push_back(d5);
dayListToAdd.push_back(d10);

// Second set object is initialized with the second List as the consturcotr parameter.
cout << "Second set object is initialized with the second List as the consturcotr parameter." << endl;
outputFile << "Second set object is initialized with the second List as the consturcotr parameter." << endl;

DayOfYearSet toAdd(dayListToAdd);
cout << "Constructor works. Here is the set: " << toAdd << endl << endl;
outputFile << "Constructor works. Here is the set: " << toAdd << endl << endl;


// Objects in the first set are printed on the screen.
cout << endl << endl << endl;

cout << "Objects in the first set: " << endl;
cout << mainSetObj << endl << endl;

outputFile << "Objects in the first set: " << endl;
outputFile << mainSetObj << endl << endl;

cout << "Objects in the second set: " << endl;
cout << toAdd << endl << endl;

outputFile << "Objects in the second set: " << endl;
outputFile << toAdd << endl << endl;

cout << "Using square bracket for single items, set1[2]  and set2[4] is shown:" << endl << endl << mainSetObj[2] <<  toAdd[4] << endl << endl;
outputFile << "Using square bracket for single items, set1[2]  and set2[4] is shown:" << endl << endl << mainSetObj[2] <<  toAdd[4] << endl << endl;


cout << endl << endl << endl;
outputFile << endl << endl << endl;


cout << "Now, + and - operator for adding and subtracting single DayOfYear objects are going to be tested:" << endl << endl;
outputFile << "Now, + and - operator for adding and subtracting single DayOfYear objects are going to be tested:" << endl << endl;


cout << " + operator for adding a single DayOfYear object into a DayOfYearSet object is tested. Set1 + d9 (May 5):" << endl;
outputFile << " + operator for adding a single DayOfYear object into a DayOfYearSet object is tested. Set1 + d9 (May 5):" << endl;

mainSetObj = mainSetObj + d9;
cout << mainSetObj << endl << endl;
outputFile << mainSetObj << endl << endl;


cout << " - operator for subtracting a single DayOfYear object from a DayOfYearSet object is tested. Set1 - d2 (March 3):" << endl;
outputFile << " - operator for subtracting a single DayOfYear object from a DayOfYearSet object is tested. Set1 - d2 (March 3):" << endl;

mainSetObj = mainSetObj - d2;
cout << mainSetObj << endl << endl;
outputFile << mainSetObj << endl << endl;

cout << endl << endl ;
outputFile << endl << endl ;


cout << "Now, + and - operators between sets are going to be tested. Here are the last states of the two sets:" << endl << endl;
outputFile << "Now, + and - operators between sets are going to be tested. Here are the last states of the two sets:" << endl << endl;

cout << "Set 1: " << mainSetObj << endl;
outputFile << "Set 1: " << mainSetObj << endl;

cout << "Set 2: " << toAdd << endl;
outputFile << "Set 2: " << toAdd << endl;



cout << endl;
outputFile << endl;

cout << " + operator for adding two sets together is tested. (Below is the output of set1 + set2)." << endl;
outputFile << " + operator for adding two sets together is tested. (Below is the output of set1 + set2)." << endl;

cout << mainSetObj + toAdd << endl << endl;
outputFile << mainSetObj + toAdd << endl << endl;


cout << " - operator for subtracting two sets is tested. (Below is the output of set1 - set2)." << endl;
outputFile << " - operator for subtracting two sets is tested. (Below is the output of set1 - set2)." << endl;

cout << mainSetObj - toAdd << endl << endl;
outputFile << mainSetObj - toAdd << endl << endl;


cout << endl << endl << endl;
outputFile << endl << endl << endl;



cout << "TESTING OF INTERSECTION (^) OPERATOR, remove() FUNCTION AND size() FUNCTION:" << endl << endl;
outputFile << "TESTING OF INTERSECTION (^) OPERATOR, remove() FUNCTION AND size() FUNCTION:" << endl << endl;

cout << "Set 1: " << mainSetObj << endl;
outputFile << "Set 1: " << mainSetObj << endl;

cout << "Set 2: " << toAdd << endl << endl;
outputFile << "Set 2: " << toAdd << endl << endl;

cout << "Intersection of set1 and set2 output is:" << endl;
outputFile << "Intersection of set1 and set2 output is:" << endl;

cout << (mainSetObj ^ toAdd) << endl;
outputFile << (mainSetObj ^ toAdd) << endl;

cout << endl;
outputFile << endl;



cout << "After using remove for removing d1 (Jan 2) from set1 (USING CALL BY REFERENCE)" << endl;
outputFile << "After using remove for removing d1 (Jan 2) from set1 (USING CALL BY REFERENCE)" << endl;

mainSetObj = mainSetObj.removerf(d1);
cout << mainSetObj << endl << endl;
outputFile << mainSetObj << endl << endl;


cout << "After using remove for removing d8 (September 10) from set1 (USING CALL BY VALUE)" << endl;
outputFile << "After using remove for removing d8 (September 10) from set1 (USING CALL BY VALUE)" << endl;

mainSetObj = mainSetObj.remove(d8);
cout << mainSetObj << endl << endl;
outputFile << mainSetObj << endl << endl;


cout << endl << endl << endl;
outputFile << endl << endl << endl;


cout << "Performing size() tests for 2 sets:" << endl << endl;
outputFile << "Performing size() tests for 2 sets:" << endl << endl;


cout << "Set 1:  "<<mainSetObj << endl;
outputFile << "Set 1:  "<<mainSetObj << endl;

cout << "Size test for set1 ( Output should be 6 for set1 ):    " << mainSetObj.size() << endl << endl;
outputFile << "Size test for set1 ( Output should be 6 for set1 ):    " << mainSetObj.size() << endl << endl;

cout << "Set 2:  "<<toAdd << endl;
outputFile << "Set 2:  "<<toAdd << endl;

cout << "Size test for set2 ( Output should be 5 for set2 ):    " << toAdd.size() << endl;
outputFile << "Size test for set2 ( Output should be 5 for set2 ):    " << toAdd.size() << endl;

cout << endl << endl << endl;
outputFile << endl << endl << endl;

cout << " == and != testing:" << endl << endl;

list<DayOfYearSet::DayOfYear> arrLeft;
arrLeft.push_back(d7);
arrLeft.push_back(d8);
arrLeft.push_back(d9);

DayOfYearSet leftSet(arrLeft);

list<DayOfYearSet::DayOfYear> arrRight;
arrRight.push_back(d9);
arrRight.push_back(d8);
arrRight.push_back(d7);

DayOfYearSet RightSet(arrRight);


cout << "The first set:  " << leftSet << endl;
cout << "The second set:  " << RightSet << endl << endl;
outputFile << "The first set:  " << leftSet << endl;
outputFile << "The second set:  " << RightSet << endl << endl;

cout << "Left Set == Right Set output:  " << (leftSet == RightSet) << endl;
cout << "Left Set != Right Set output:  " << (leftSet != RightSet) << endl << endl;
outputFile << "Left Set == Right Set output:  " << (leftSet == RightSet) << endl;
outputFile << "Left Set != Right Set output:  " << (leftSet != RightSet) << endl << endl;


cout << "Adding one more element to Left set and comparing again." << endl << endl;
outputFile << "Adding one more element to Left set and comparing again." << endl << endl;

leftSet = leftSet + d6;

cout << "The first set:  " << leftSet << endl;
cout << "The second set:  " << RightSet << endl << endl;

outputFile << "The first set:  " << leftSet << endl;
outputFile << "The second set:  " << RightSet << endl << endl;

cout << "Left Set == Right Set output:  " << (leftSet == RightSet) << endl;
cout << "Left Set != Right Set output:  " << (leftSet != RightSet) << endl << endl << endl;
outputFile << "Left Set == Right Set output:  " << (leftSet == RightSet) << endl;
outputFile << "Left Set != Right Set output:  " << (leftSet != RightSet) << endl << endl << endl;



cout << "Complement set test, !set1 output is: " << endl << endl;
outputFile << "Complement set test, !set1 output is: " << endl << endl;


cout << !mainSetObj << endl << endl;
outputFile << !mainSetObj << endl << endl;

outputFile.close();

return 0;

}
