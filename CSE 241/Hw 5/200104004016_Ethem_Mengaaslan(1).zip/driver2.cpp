#include "driver2.hpp"
#include "driver1.hpp"


using namespace std;
using namespace tetClass;


int numOfMoves(int totalMvs){
	cout << "Total number of moves made:  " << totalMvs << endl;
	return totalMvs;
}

template <class T>
void writeToFile(TetrisAdapter<T>& playground, const string& fileName)
{
    ofstream outFile(fileName);

    if (outFile.is_open())
    {
        for (const auto& row : playground.getBoard())
        {
            for (const auto& cell : row)
            {
                outFile << cell;
                if (cell != row.back())
                {
                    outFile << "";
                }
            }
            outFile << endl;
        }

        outFile.close();
    }
    else
    {
        cerr << "Error opening file for writing." << endl;
    }

	cout << "Game saved succesfully." << endl;
}

void writeToFile(TetrisVector& playground, const string& fileName)
{
    ofstream outFile(fileName);

    if (outFile.is_open())
    {
        for (const auto& row : playground.getBoard())
        {
            for (const auto& cell : row)
            {
                outFile << cell;
                if (cell != row.back())
                {
                    outFile << "";
                }
            }
            outFile << endl;
        }

        outFile.close();
    }
    else
    {
        cerr << "Error opening file for writing." << endl;
    }
	
	cout << "Game saved succesfully." << endl;

}

void writeToFile(Tetris1D& playground, const string& fileName)
{
	cout << "Save functionality is not present for Tetris1D class." << endl;

}


template<class T>
void readFromFile(TetrisAdapter<T>& playground, string filename) {
  // Open the CSV file
  auto cFileName = filename.c_str();
  FILE *file = fopen(cFileName, "r");
  if (file == NULL) {
    cerr << "Save file doesn't exist. Program terminating." << endl;
    return;
  }

  // Read the Tetris board from the CSV file and count the number of horizontal and vertical elements
  int row = 0;
  int col = 0;
  int width = 0;
  int length = 0;
  char c;
  while ((c = fgetc(file)) != EOF) {
    if (c == '\n') {
      row++;
      if (col > width) {
        width = col;
      }
      col = 0;
    } else {
      col++;
    }
  }
  if (col > width) {
    width = col;
  }
  length = row;

  // Resize the board and set its dimensions
  playground.setLength(length);
  playground.setWidth(width);
  playground.resizeBoard(width, length);

  // Read the data from the CSV file and store it in the board
  fseek(file, 0, SEEK_SET);
  row = 0;
  col = 0;
  while ((c = fgetc(file)) != EOF) {
    if (c == '\n') {
      row++;
      col = 0;
    } else if (c != ',') {
      playground.board[row][col] = c;
      col++;
    }
  }

  // Close the CSV file
  fclose(file);
}


void readFromFile(TetrisVector& playground, string filename) {
  // open the .csv file
  auto cFileName = filename.c_str();
  FILE *file = fopen(cFileName, "r");
  if (file == NULL) {
	cerr << "Couldn't open related file." << endl;
    exit(1);
  }

  // read the tetris board from the csv file and count the number of horizontal and vertical elements, to find width and length of the object.
  int row = 0;
  int col = 0;
  int width = 0;
  int length = 0;
  char c;
  while ((c = fgetc(file)) != EOF) {
    if (c == '\n') {
      row++;
      if (col > width) {
        width = col;
      }
      col = 0;
    } else {
      col++;
    }
  }
  if (col > width) {
    width = col;
  }
  length = row;

  // Resize the board and set its dimensions
  playground.setLength(length);
  playground.setWidth(width);
  playground.resizeBoard(width, length);

  // Read the data from the CSV file and store it in the board
  fseek(file, 0, SEEK_SET);
  row = 0;
  col = 0;
  while ((c = fgetc(file)) != EOF) {
    if (c == '\n') {
      row++;
      col = 0;
    } else if (c != ',') {
      playground.board[row][col] = c;
      col++;
    }
  }

  // close file
  fclose(file);

  
}

void readFromFile(Tetris1D& playground, string filename){
	cout << "Save funcionality is not available for Tetris1D class." << endl;
	exit(1);
}


void printCSV(string filename) {
  // Open the file
  ifstream file(filename);

  // Read the file line by line
  string line;
  while (getline(file, line)) {
    // Print the line
    cout << line << endl;
  }
}


template<class T>
void run_game(T& playground){

	int totalMvs = 0;	
    int i = 0;
	int width;
	int length;
	int tetroNumber;  // Number of tetrominos which'll be entered.
	char moveDirection;
	int moveCount;
	char rotateDirection;
	int rotateCount;
	char inpchar;
	LastMove lastmove;
	int newGame = 0;
	int dataTypeSelection;
	int adapterSelection;

	cout << "Press 1 for new game, 2 for saved game. " << endl;
	cin >> newGame;

	if(newGame == 1){
	cout << "Please enter the width of the board: ";
	cin >> width;
	// Checks for bad inputs, asks again if any.

	while( cin.fail() ){
		cin.clear();
		cin.ignore();
		cout << "Please enter a valid input." << endl;
		cin >> width;
	}
	const int arrayN = width;
	cout << "Please enter the length of the board: ";
	cin >> length;

	while( cin.fail() ){
		cin.clear();
		cin.ignore();
		cout << "Please enter a valid input." << endl;
		cin >> length;
	}
	playground.setWidth(width);
	playground.setLength(length);
	playground.resizeBoard(width,length);
	playground.createBoard(width,length);
	playground.Draw(width,length);

	}
	else if(newGame == 2){
		readFromFile(playground, "save.csv");
		playground.Draw(playground.getWidth(),playground.getLength());
	}


	
	
	cout << "Please enter the number of tetrominos" << endl;
	cin >> tetroNumber;

	
	while( cin.fail() ){
		cin.clear();
		cin.ignore();
		cout << "Please enter a valid input." << endl;
		cin >> tetroNumber;
	}

	// Runs the program for the requested number of tetrominos.

	for(i=0;i<tetroNumber;i++){
		cout << "Enter tetromino type (O,I,T,J,L,S,Z) or R for Random Tetromino, or Enter q to terminate program." << endl;
		cout << "You can also enter X to see the last move or N for total number of moves made until now." << endl;
		cout << "Please enter V whenever you want to save your current game." << endl;
		cin >> inpchar;
		// If the user enters R, the tetromino is chosen randomly.
		if(inpchar == 'R'){
			srand(time(0));
			int randInt = rand();
			if( randInt %7 == 0){
				inpchar = 'O';
			}else if(randInt %7 == 1){
				inpchar = 'I';
			}else if(randInt %7 == 2){
				inpchar = 'T';
			}else if(randInt %7 == 3){
				inpchar = 'J';
			}else if(randInt %7 == 4){
				inpchar = 'L';
			}else if(randInt %7 == 5){
				inpchar = 'S';
			}else if(randInt %7 == 6){
				inpchar = 'Z';
			}else{
				cout << "PLEASE REACH THE DEVELOPER, OR SHOT HIM IN THE HEAD (TWICE) IF YOU WANT TO BE COOPERATIVE." << endl;
			}
		}
		if(inpchar == 'X' || inpchar == 'x'){
			lastmove.output(i);
			i--;
		}else if(inpchar == 'N' || inpchar == 'n'){
			numOfMoves(totalMvs);
		}else if(inpchar == 'V' || inpchar == 'v'){
			writeToFile(playground, "save.csv");
		}else{
			std::cout << "\x1B[2J\x1B[H"; 
			cin. clear();
			Tetromino toGo(inpchar);
			if(i==0){
				toGo.fixFirst(toGo);
			}
			lastmove.tetroType = inpchar;
			playground.Animate(toGo,rotateDirection,rotateCount,moveDirection,moveCount,lastmove);
		}

		totalMvs+=lastmove.rotationAmt;
		totalMvs+=lastmove.moveAmt;

	}
	
}


int main(){

	int totalMvs = 0;	
    int i = 0;
	int width;
	int length;
	int tetroNumber;  // Number of tetrominos which'll be entered.
	char moveDirection;
	int moveCount;
	char rotateDirection;
	int rotateCount;
	char inpchar;
	LastMove lastmove;
	int newGame = 0;
	int dataTypeSelection;
	int adapterSelection;
	//TetrisAdapter<std::deque<std::deque<char>> > playground;

	cout << "Please choose the data type:" << endl;
	cout << "1 for TetrisVector (Stores the board as a Vector)" << endl;
	cout << "2 for Tetris1D (Stores the board as a 1D array)" << endl;
	cout << "3 for TetrisAdapter (Stores the board as an STL container class which has a random access iterator)" << endl;
	cin >> dataTypeSelection;
	

	if(dataTypeSelection == 1){
		TetrisVector playground;
		run_game(playground);
	}else if(dataTypeSelection == 2){
		Tetris1D playground;
		run_game(playground);
	}else if(dataTypeSelection == 3){
		cout << "STL container classes who has random access iterators are:" << endl;
		cout << "1. Vector" << endl << "2. Deque" << endl <<"3. Array" << endl;
		cin >> adapterSelection;
		if(adapterSelection == 1){
			TetrisAdapter<vector<vector<char> > > playground;
			run_game(playground);
		}else if(adapterSelection == 2){
			TetrisAdapter<deque<deque<char> > > playground;
			run_game(playground);
		}else if(adapterSelection == 3){
			cout << "Since arrays work with constant integers as size parameters, and this program is getting the size on run-time (as you are reading this message), this functionality is technically impossible. Please run the program again and choose 1 or 2." << endl;
			exit(1);
		}
	}


	
	return 0;


}