#include "driver1.hpp"
#include "driver2.hpp"

using namespace std;
using namespace tetClass;

int numOfMoves(int totalMvs){
	cout << "Total number of moves made:  " << totalMvs << endl;
	return totalMvs;
}

template<class T>
void test_func(T& playground){

	int totalMvs = 0;	
    int i = 0;
	int width = 16;
	int length = 16;
	int tetroNumber;  // Number of tetrominos which'll be entered.
	char moveDirection;
	int moveCount;
	char rotateDirection;
	int rotateCount;
	char inpchar;
	LastMove lastmove;
	int newGame = 0;
	int dataTypeSelection;
	int adapterSelection;

	cout << "Width: 16 and Length: 16 is set for test.";
	// Checks for bad inputs, asks again if any.

	playground.setWidth(width);
	playground.setLength(length);
	playground.resizeBoard(width,length);

    cout << "Board is being created." << endl;

	playground.createBoard(width,length);
	playground.Draw(width,length);

	
	cout << "Adding 3 random tetrominos and animating:" << endl;
    cout << "Printing lastMove and numberOfMoves details in each step." << endl;

    for(i=0;i<3;i++){

			srand(time(0));
			int randInt = rand();
			if( randInt %7 == 0){
				inpchar = 'O';
			}else if(randInt %7 == 1){
				inpchar = 'I';
			}else if(randInt %7 == 2){
				inpchar = 'T';
			}else if(randInt %7 == 3){
				inpchar = 'J';
			}else if(randInt %7 == 4){
				inpchar = 'L';
			}else if(randInt %7 == 5){
				inpchar = 'S';
			}else if(randInt %7 == 6){
				inpchar = 'Z';
			}
		
			cin. clear();
			Tetromino toGo(inpchar);
			if(i==0){
				toGo.fixFirst(toGo);
			}
			lastmove.tetroType = inpchar;
			playground.Animate(toGo,rotateDirection,rotateCount,moveDirection,moveCount,lastmove);

            totalMvs+=lastmove.rotationAmt;
		    totalMvs+=lastmove.moveAmt;

            
            lastmove.output(i);
           
            numOfMoves(totalMvs);

           

            cout << i+1<<"/"<<3<<" of this test is completed." << endl;

    }

	
	
}


int main(){

	Shapes tetromino_type;
	int tetrominos_number;
	int i = 0;
	char tetrotype;
	int width;
	int length;
	int tetroNumber;
	char charType;
    char keepTesting;
    cout << "All of the STL container classes with random access iterators will be tested." << endl;
    cout << "Every container class tetris board will be tested with 3 random tetrominos (randomly decided on the runtime)" << endl;
    cout << "This takes a little bit of time. Between the tests, you'll be asked to whether continue or finish the test." << endl << endl; 

    cout << "Enter Q to skip test, or Y to start with the first test." << endl;
    cin >> keepTesting;
    if(keepTesting == 'q' || keepTesting == 'Q'){
        cerr<< "Test is being terminated...";
        return 0;
    }

    cout << endl << endl <<"Test of TetrisVector" << endl << endl;
    TetrisVector playground;
    test_func(playground);

    cout << "Enter Q to finish test, or Y to move to the next test." << endl;
    cin >> keepTesting;
    if(keepTesting == 'q' || keepTesting == 'Q'){
        cerr<< "Test is being terminated..."; //throw runtime_error("Test is being terminated...");
        return 0;
    }
    std::cout << "\x1B[2J\x1B[H";

    cout << endl << endl <<"Test of Tetris1D" << endl << endl;
    Tetris1D playground2;
    test_func(playground2);

    cout << "Enter Q to finish test, or Y to move to the next test." << endl;
    cin >> keepTesting;
    if(keepTesting == 'q' || keepTesting == 'Q'){
        cerr<< "Test is being terminated..."; //throw runtime_error("Test is being terminated...");
        return 0;
    }
	std::cout << "\x1B[2J\x1B[H";

    cout << endl << endl <<"Test of TetrisAdapter" << endl << endl;

    cout << endl << endl <<"Test of TetrisAdapter of type STL Deque" << endl << endl;
    TetrisAdapter<deque<deque<char> > > playground3;
    test_func(playground3);

    cout << "Enter Q to finish test, or Y to move to the next test." << endl;
    cin >> keepTesting;
    if(keepTesting == 'q' || keepTesting == 'Q'){
        cerr<< "Test is being terminated..."; //throw runtime_error("Test is being terminated...");
        return 0;
    }
	std::cout << "\x1B[2J\x1B[H";

    cout << endl << endl <<"Test of TetrisAdapter of type STL Vector" << endl << endl;
    TetrisAdapter<vector<vector<char> > > playground4;
    test_func(playground4);

    cout << "Enter Q to finish test, or Y to move to the next test." << endl;
    cin >> keepTesting;
    if(keepTesting == 'q' || keepTesting == 'Q'){
        cerr<< "Test is being terminated..."; //throw runtime_error("Test is being terminated...");
        return 0;
    }
	std::cout << "\x1B[2J\x1B[H";


	return 0;

}