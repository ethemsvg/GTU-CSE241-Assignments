#include <iostream>
#include <vector>
#include <deque>
#include <fstream>
#include "driver2.hpp"

#ifndef _DRIVER1_HPP_
#define _DRIVER1_HPP_

using namespace std;
using namespace tetClass;

namespace tetClass{

class Tetris{


	public:
		
		
		
		virtual int** Meaningful2Dgenerator(Tetromino piece); // Creates a Meaningful 2D vector out of 4x4 vectors.
		virtual void Animate(Tetromino &piece, char rotateDirection, int rotateCount, char moveDirection, int moveCount, LastMove &lastmove) = 0; // Animates the moves.
        // BELOW ARE PURE VIRTUAL FUNCTIONS
		virtual Coordinate TetroPlacer(Tetromino piece, char moveDirection, int moveCount) = 0; // Decides where to place the tetromino.
		virtual void SlideTetrominoLR(Tetromino piece, char direction) = 0; // Moves the tetromino horizontally by one unit to the left or right.
		virtual void LowerTetromino(Tetromino piece, char moveDirection, int moveCount) = 0; // Lowers the tetromino step by step to the bottom.
		virtual Tetris& operator-=(Tetromino piece) = 0;
		virtual void resizeBoard(const int& width, const int& length) = 0; // Resizes the board.
		virtual void createBoard(const int& width, const int& length) = 0; // Creates the board.
		virtual void Draw(const int& width, const int& length) = 0; // Draws the board.
		virtual Tetris& operator+=(Tetromino piece) = 0;
		virtual void isGameOver() = 0;
	private:
		//char** board;
		//int width;
		//int length;
		int isBotFull = 0; 													// I think this is a garbage variable, i'll check the rest of the code since i doN't remember what i have done.
		int tetrominoCounter = 0;
};

class TetrisVector: public Tetris{

public:
    TetrisVector();
    TetrisVector(int& w, int& l);
    ~TetrisVector(){}

	 void setWidth(int &w){
			width = w;
		}
		 void setLength(int &l){
			length = l;
		}
         int getWidth(){
            return width;
        }
         int getLength(){
            return length;
        }
	vector<vector<char> > getBoard(){
		return board;
	}
	void Animate(Tetromino &piece, char rotateDirection, int rotateCount, char moveDirection, int moveCount, LastMove &lastmove); 
    Coordinate TetroPlacer(Tetromino piece, char moveDirection, int moveCount);
    void SlideTetrominoLR(Tetromino piece, char direction); // Moves the tetromino horizontally by one unit to the left or right.
	void LowerTetromino(Tetromino piece, char moveDirection, int moveCount); // Lowers the tetromino step by step to the bottom.
	Tetris& operator-=(Tetromino piece);
	void resizeBoard(const int& width, const int& length); // Resizes the board.
	void createBoard(const int& width, const int& length); // Creates the board.
	void Draw(const int& width, const int& length); // Draws the board.
	Tetris& operator+=(Tetromino piece);
	void isGameOver();    
    vector<vector<char>> board;



private:
    int width;
	int length;
	int isBotFull = 0; 													// I think this is a garbage variable, i'll check the rest of the code since i doN't remember what i have done.
	int tetrominoCounter = 0;

};

class Tetris1D: public Tetris{

public:
   
	Tetris1D();
    Tetris1D(int& w, int& l);//: Tetris(w,l){
	~Tetris1D(){}

 	void setWidth(int &w){
		width = w;
	}
	void setLength(int &l){
		length = l;
	}
	 int getWidth(){
        return width;
    }
    int getLength(){
        return length;
    }

	void Animate(Tetromino &piece, char rotateDirection, int rotateCount, char moveDirection, int moveCount, LastMove &lastmove); 
    Coordinate TetroPlacer(Tetromino piece, char moveDirection, int moveCount);
    void SlideTetrominoLR(Tetromino piece, char direction); // Moves the tetromino horizontally by one unit to the left or right.
	void LowerTetromino(Tetromino piece, char moveDirection, int moveCount); // Lowers the tetromino step by step to the bottom.
	Tetris& operator-=(Tetromino piece);
	void resizeBoard(const int& width, const int& length); // Resizes the board.
	void createBoard(const int& width, const int& length); // Creates the board.
	void Draw(const int& width, const int& length); // Draws the board.
	Tetris& operator+=(Tetromino piece);
	void isGameOver();    



private:
    char* board;
    int width;
	int length;
	int isBotFull = 0; 													// I think this is a garbage variable, i'll check the rest of the code since i doN't remember what i have done.
	int tetrominoCounter = 0;

};

template <class T>
class TetrisAdapter{
public:
	TetrisAdapter(){}
    TetrisAdapter(int &w, int &l): board(){
		setWidth(w);
		setLength(l);
    	resizeBoard(w,l);
		cout <<"Board has succesfully initalized." << endl;
	}
	~TetrisAdapter(){
		
	}

	void setWidth(int &w){
		width = w;
	}
	void setLength(int &l){
		length = l;
	}
    int getWidth(){
        return width;
    }
    int getLength(){
        return length;
    }
	int** Meaningful2Dgenerator(Tetromino piece); // Creates a Meaningful 2D vector out of 4x4 vectors.

	void Animate(Tetromino &piece, char rotateDirection, int rotateCount, char moveDirection, int moveCount, LastMove &lastmove); 
    Coordinate TetroPlacer(Tetromino piece, char moveDirection, int moveCount);
    void SlideTetrominoLR(Tetromino piece, char direction); // Moves the tetromino horizontally by one unit to the left or right.
	void LowerTetromino(Tetromino piece, char moveDirection, int moveCount); // Lowers the tetromino step by step to the bottom.
	TetrisAdapter<T>& operator-=(Tetromino piece);
	void resizeBoard(const int& width, const int& length); // Resizes the board.
	void createBoard(const int& width, const int& length); // Creates the board.
	void Draw(const int& width, const int& length); // Draws the board.
	TetrisAdapter<T>& operator+=(Tetromino piece);
	void isGameOver();    
	T getBoard(){
		return board;
	}
    T board;



private:
    int width;
	int length;
	int isBotFull = 0; 													// I think this is a garbage variable, i'll check the rest of the code since i doN't remember what i have done.
	int tetrominoCounter = 0;


};


}




// Idk why but i kept getting makefile error, moving the TetrisAdapter<T> function implementations to here solved the problem.






/*

Tetromino piece: The tetromino who's 4x4 array will be turned into another 2D array with no competely empty rows or columns.

This function creates 2x2,2x3,3x2,4x1,1x4 etc. arrays from 4x4 arrays by stripping away the completely empty rows and columns.

*/


template<class T>
int** TetrisAdapter<T>::Meaningful2Dgenerator(Tetromino piece){

	int i=0;
	int j=0;

	// The 2D array is created with no size.


	// The upmost meaningful row and rightmost meaningful column is detected.

	int MeaningfulRow = piece.meaningful_row_func(piece);
	int MeaningfulColumn = piece.meaningful_column_func(piece);

	int numOfRows = 4 - MeaningfulRow; 
	int numOfColumns = MeaningfulColumn + 1;

	// The empty array is resized in accordance to the number of rows and columns of the tetromino.

	// Resize of the rows.

	int **meaningful2D = new int*[numOfRows];

	// Resize of the columns.

	for(i=0;i<numOfRows;i++){
		meaningful2D[i] = new int[numOfColumns];
	}

	// Fills the 2D Meaningful array from the 4x4 default array.
	for(i=piece.meaningful_row_func(piece);i<4;i++){ 

		for(j=0;j<=piece.meaningful_column_func(piece);j++){ 

			meaningful2D[i-piece.meaningful_row_func(piece)][j] = piece.getTetrominoMatrix()[i][j];
		}

	}


	// The final Meaningful 2D array of the tetromino is returned.

	return meaningful2D;
}

/*

const int& width: The width of the board. 
const int& length: The length of the board.

Displays the board on the terminal screen by basically looping through every unit on the board array.

*/

template<class T>
void TetrisAdapter<T>::Draw(const int& width, const int& length){

	int i=0;
	int j=0;

	for(i=0;i<length;i++){

		for(j=0;j<width;j++){

			cout << board[i][j];
		}

		cout << endl;

	}

	return;

}

/*

const int& width: The width of the board. 
const int& length: The length of the board.

Creates an empty board with borders and empty units.

*/

template<class T>
void TetrisAdapter<T>::createBoard(const int& width, const int& length){

	int i=0;
	int j=0;


	for(i=0;i<length;i++){ 

		for(j=0;j<width;j++){

			if(i==0 || i==length-1){

				board[i][j] = '#';

			}else if(j==0 || j==width-1){

				board[i][j] = '#';

			}else{

				board[i][j] = '.';
			}

		}

	} 

	
}
/*

Checks whether the game is over or not.

*/
template<class T>
void TetrisAdapter<T>::isGameOver(){

	int i=0;

	for(i=1;i<width-1;i++){
		if(board[1][i] != '.'){
			cout << "The Game Is Over. Thanks For Playing..." << endl;
			exit(1);
		}
	}

}

/*

Tetromino &piece: The piece which'll be removed from the board.


Removes tetromino from the board. This function is needed for re-drawing the board after the rotation to avoid overlaps.

*/

template <class T>
TetrisAdapter<T>& TetrisAdapter<T>::operator-=(Tetromino piece){

	int MeaningfulColumn = piece.meaningful_column_func(piece);
	int MeaningfulRow = piece.meaningful_row_func(piece);
	
	int numOfRows = 4 - MeaningfulRow;  // Number of rows of the tetromino piece.
	int numOfColumns = MeaningfulColumn + 1; // Number of columns of the tetromino piece.

	int startColm = (width/2) - 1; 
	int i,j,k,l;

	int** meaningful2D;

	meaningful2D = this->Meaningful2Dgenerator(piece); // Meaningful 2D array is created.

	// Loops through the first few rows (according to the vertical size of the tetromino),
	// To find any full units, if found, clears them.

	for(i=0;i<(numOfRows);i++){
		for(j=0;j<(numOfColumns);j++){
			if(meaningful2D[i][j] == 1){
				board[i+1][j+startColm] = '.';
			}else if(meaningful2D[i][j] == 0){
				board[i+1][j+startColm] = '.'; 
			}
		}
	}

	return *this;

}

/*

Tetromino &piece: The tetromino object which'll be added and animated in the board.

char rotateDirection: Direciton of rotation (L for Left, R for Right)

int rotateCount: Amount of rotation

char moveDirection: Direction of movement (L for Left, R for Right)

int moveCount: Amount of movement

LastMove &lastmove: A LastMove object to store the details of the move which is being made.



Animate function to animate the added tetromino dropping to the
bottom of the board. 

The animation will be repetition of four steps:

1. Draw the board with Tetromino at the top
2. Ask the user rotation direction and rotation count
3. Ask the user move direction and count
4. Rotate and move the Tetromino
5. Draw the board
6. Sleep 50 milliseconds
7. Lower the Tetromino one level and go to step 5 until it
hits the bottom.

*/
template <class T>
void TetrisAdapter<T>::Animate(Tetromino &piece, char rotateDirection, int rotateCount, char moveDirection, int moveCount, LastMove &lastmove){

	int i=0;
	int j=0;
	int startColm = (width/2) - 1;

	*this+=piece;

	Draw(width,length);

	cout << "Please enter rotation direction (L for Left, R for Right)" << endl;
	cin >> rotateDirection;

	// Add exception for invalid rotate direction
	if (rotateDirection != 'L' && rotateDirection != 'R') {
		throw invalid_argument("Invalid rotate direction. Please enter L for Left or R for Right.");
        return;
	}

	cout << "Please enter rotation count" << endl;
	cin >> rotateCount;

	// Add exception for negative rotate count
	if (rotateCount < 0) {
		throw invalid_argument("Invalid rotate count. Please enter a value bigger than zero.");
        return;

	}

	cout << "Please enter move direction (L for Left, R for Right)" << endl;
	cin >> moveDirection;

	// Add exception for invalid move direction
	if (moveDirection != 'L' && moveDirection != 'R') {
		throw invalid_argument("Invalid move direction. Please enter L for Left or R for Right.");
        return;

	}

	cout << "Please enter move count" << endl;
	cin >> moveCount;

	// Add exception for negative move count
	if (moveCount < 0) {
		throw invalid_argument("Invalid move amount. Please enter a value bigger than zero.");
        return;

	}


	for(i=0;i<rotateCount;i++){
		*this -= piece;
		piece.rotate_tetromino(rotateDirection);
		*this += piece;
		std::cout << "\x1B[2J\x1B[H";
		Draw(width,length);
		usleep(500000);

	}


	while(startColm + moveCount + piece.meaningful_column_func(piece) >= width-1){
		cout << "Move amount is out of boundaries of the board. Please enter a new value:" << endl;
		cin >> moveCount;
	}

	lastmove.setMoveAmt(moveCount);// = moveCount;
	lastmove.setRotationAmt(rotateCount);// = rotateCount;
	lastmove.setMoveDir(moveDirection);// = moveDirection;
	lastmove.setRotationDir(rotateDirection);// = rotateDirection;

	// The suitable destination coordinate for the tetromino is received.
	// and the board is drawn.
	Coordinate coordinate = TetroPlacer(piece,moveDirection,moveCount); 
	

	int destinationRow = coordinate.getRow();
	int destinationColumn= coordinate.getColumn();
	
	int slideAmount;
	char slideDirection;

	// If the destination column is on the left side of the start column, the slide direction is Left,
	// and the slide amount is the difference between them.

	if( startColm > destinationColumn ){

		slideAmount = startColm - destinationColumn;
		slideDirection = 'L';

		for(i=0;i<slideAmount;i++){
			
			// The tetromino is slided the necessary units in the necessary direction.

			SlideTetrominoLR(piece,slideDirection);
			std::cout << "\x1B[2J\x1B[H";
			Draw(width,length);
			usleep(500000);
		
		}

	// If the destination column is on the right side of the start column, the slide direction is Right,
	// and the slide amount is the difference between them.

	}else if( startColm < destinationColumn ){

		slideAmount = destinationColumn - startColm;
		slideDirection = 'R';

		for(i=0;i<slideAmount;i++){

			// The tetromino is slided the necessary units in the necessary direction.

			SlideTetrominoLR(piece,slideDirection);
			std::cout << "\x1B[2J\x1B[H";
			Draw(width,length);
			usleep(500000);
		}

	}else{

		cout << "Slide amount is 0" << endl;

	}


	// Then the tetromino is lowered as an animation row by row, as many rows as possible which is calculated on the LowerTetromino function.

	LowerTetromino(piece,moveDirection,moveCount);

	isGameOver();

}

/*

Tetromino piece: The tetromino which'll be fitted.
int shiftRow: A control value for whether the value of the lowest row possible to search for a fit value will be shifted upwards (only if necessary.)

Scans the board from top down in forms of the size of the tetromino, looking for fit positions where the existence of the tetromino would not interfere
with any other full units.

*/

template <class T>
Coordinate TetrisAdapter<T>::TetroPlacer(Tetromino piece, char moveDirection, int moveCount){

	Coordinate coordinate;
	
	int i=0;
	int j=0;
	
	int lowestRow = length-1; // Lowest row on the tetris board which can hold tetrominos.
	int startColm = (width/2) - 1; 
	int breakcheck = 0;
	int priorityLowestRow; // The lowest row with any empty spaces to search for fit places on the board.
	int priorityStartingRow; // The starting row of the tetromino when being written on the board (the tetromino is started to being written on the left upper unit.)
	int numOfRows = 4 - piece.meaningful_row_func(piece);
	int numOfColumns = piece.meaningful_column_func(piece) + 1;
	int temp;
	int** meaningful2D;
	meaningful2D = this->Meaningful2Dgenerator(piece);

	

	// The lowest row possible for fitting is detected.
	
	for(i=length-1;i>1;i--){	
		for(j=1;j<width;j++){
			if(board[i][j] == '.' && board[i-1][j] == '.'){
				priorityLowestRow = i;
				breakcheck = 1;
				break;
			}
		}
		if(breakcheck == 1){
			break;
		}
	}

	

	priorityStartingRow = priorityLowestRow - (numOfRows-1);


	coordinate.setRow(priorityLowestRow);

	if(moveDirection == 'R'){

		temp = startColm + moveCount;
		coordinate.setColumn(temp);

	}else if(moveDirection == 'L'){
		temp = startColm - moveCount;
		coordinate.setColumn(temp);
	}


	return coordinate;

}

/*

Tetromino piece: The tetromino which'll be added to the board (with any rotation position).

Adds the parameter tetromino to the top middle of the board.

*/

template <class T>
TetrisAdapter<T>& TetrisAdapter<T>::operator+=(Tetromino piece){
	int MeaningfulColumn = piece.meaningful_column_func(piece);
	int MeaningfulRow = piece.meaningful_row_func(piece);
	
	int numOfRows = 4 - MeaningfulRow; 
	int numOfColumns = MeaningfulColumn + 1;


	int startColm = (width/2) - 1; 
	int i,j,k,l;

	int** meaningful2D;

	meaningful2D = this->Meaningful2Dgenerator(piece);


	for(i=0;i<(numOfRows);i++){

		// Overwrites the meaningful 2D array of the Tetromino to the board 
		// on the correct position.

		for(j=0;j<(numOfColumns);j++){
			if(meaningful2D[i][j] == 1){

				board[i+1][j+startColm] = piece.typechar;
			}else if(meaningful2D[i][j] == 0){
				board[i+1][j+startColm] = '.'; 
			}
		}
	}

	return *this;

}

/*

Tetromino piece: The tetromino which'll be moved.

Lowers the recently added tetromino to the minimum row level possible.

*/

template <class T>
void TetrisAdapter<T>::LowerTetromino(Tetromino piece, char moveDirection, int moveCount){ 

	int MeaningfulColumn = piece.meaningful_column_func(piece);
	int MeaningfulRow = piece.meaningful_row_func(piece);
	int shiftRow = 0;
	int numOfRows = 4 - MeaningfulRow; 
	int numOfColumns = MeaningfulColumn + 1;

	cout << "Num of columns is: " << numOfColumns << endl;
	cout << "Num of rows is : " << numOfRows << endl;

	int i=0;
	int j=0;

	// The coordinate values of the fit place is received.

	Coordinate coordinate = TetroPlacer(piece,moveDirection,moveCount);	
	

	// The bottom limit of the lowering process is received from the Fit function.

	int botLimitRow = coordinate.getRow(); 
	int PieceStartColm=0;
	int k=0;
	int breakcheck=0;

	int** meaningful2D = this->Meaningful2Dgenerator(piece);

	// The starting point of the Tetromino's current location is detected.
	// There is a special case for a certain rotation position of the J tetromino.

	for(i=0;i<length;i++){
	
		for(j=0;j<width;j++){
			if(board[1][j] == piece.typechar || board[2][j] == piece.typechar ){
				PieceStartColm = j;
				if( (piece.typechar == 'J' ) && meaningful2D[0][0] != 1){
					PieceStartColm--;
				}
				breakcheck = 1;
				break;
			}
	
		}
		if(breakcheck == 1){
			break;
		}
	}

	breakcheck = 0;

	// The tetromino is shifted downwards starting from the lowest row to one row below, so there is no overlapping.

		for(i=1;i<(botLimitRow-numOfRows+1);i++){ // 
			if(breakcheck == 1){
				break;
			}
			for(j=PieceStartColm;j<numOfColumns+PieceStartColm;j++){
				if(board[i+numOfRows][j] != '.' ){
						breakcheck = 1;
						break;
				}
				for(k=numOfRows;k>0;k--){
					if(breakcheck == 1){
						break;
					}
					if( (board[i+k-1][j] == piece.typechar) && breakcheck != 1){

						board[i+k][j] = board[i+k-1][j]; 
						board[i+k-1][j] = '.';
					}
				}
					board[i][j] = '.'; 
			}
			std::cout << "\x1B[2J\x1B[H";
			Draw(width,length);
			usleep(50000);
			if(breakcheck == 1){break;}

		}


}

/*

Tetromino piece: The piece which'll be slided.

char direction: The direction which the tetromino will be slided. (Left or Right).

The tetromino is slided to left or right by one units. 

*/

template <class T>
void TetrisAdapter<T>::SlideTetrominoLR(Tetromino piece, char direction){

	int MeaningfulColumn = piece.meaningful_column_func(piece);
	int MeaningfulRow = piece.meaningful_row_func(piece);
	
	int numOfRows = 4 - MeaningfulRow; 
	int numOfColumns = MeaningfulColumn + 1;

	int startColm;
	int i=0;
	int j=0;
	int breakcheck = 0;

	int** meaningful2D = this->Meaningful2Dgenerator(piece);

	// The starting point of the Tetromino's current location is detected.
	// There is a special case for a certain rotation position of the J tetromino.

	for(i=0;i<width;i++){
		if(board[1][i] == piece.typechar || board[2][i] == piece.typechar){
			startColm = i;
			if((piece.typechar == 'J') && meaningful2D[0][0] != 1){
				startColm--;
			}

			break;
		}

	}


	// The tetromino is shifted to the right column by column. The shifting starts with the rightmost column of the tetromino.

	if(direction == 'R'){

			for(i=1;i<numOfRows+1;i++){
					
					//if(breakcheck == 1){
						//break;
					//}
					for(j=0;j<numOfColumns+1;j++){

						//if(board[i][(startColm + numOfColumns) - j] != '.'){
							//breakcheck = 1;
							//break;
						//}
		
						if(j == numOfColumns){
							board[i][(startColm + numOfColumns) - j] = '.';
						}
						board[i][(startColm + numOfColumns) - j] = board[i][(startColm + numOfColumns) - j -1];
					}
		
			}
		
	}

	// The tetromino is shifted to the left column by column. The shifting starts with the leftmost column of the tetromino.

	if(direction == 'L'){

		for(i=1;i<numOfRows+1;i++){

			for(j=0;j<numOfColumns+1;j++){
										

				board[i][ (startColm - 1)  + j ] = board[i][ startColm +j  ];
			}
		}
	}

}

/*

const int& width: The width of the board which is taken from the user as an input.
const int& length: The length of the board which is taken from the user as an input.

This function basically resizes the 2D board array in accordance to the width and length values.

*/

template <class T>
void TetrisAdapter<T>::resizeBoard(const int& width, const int& length){
	
	int i=0;

	board.resize(length);
	for (int i = 0; i < length ; ++i){
    	board[i].resize(width);
	}


}



#endif